# -*- coding: utf-8 -*-

BOT_NAME = 'sc_scripts_demo'

SPIDER_MODULES = ['sc_scripts_demo.spiders']
NEWSPIDER_MODULE = 'sc_scripts_demo.spiders'

USER_AGENT = 'sc_scripts_demo (http://scrapinghub.com)'

ROBOTSTXT_OBEY = True
