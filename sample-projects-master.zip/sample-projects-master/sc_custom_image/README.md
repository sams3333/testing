## Scrapy Cloud Custom Image

Sample Scrapy project demonstrating using PhantomJS and
deploying it to Scrapy Cloud using a custom Docker image.
